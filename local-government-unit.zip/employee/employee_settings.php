<?php 
include('./employee/assets/config/dbconn.php');

include('./employee/assets/inc/header.php');

include('./employee/assets/inc/sidebar.php');

include('./employee/assets/inc/navbar.php');

?> 


<div class="data-card">
    <div class="card">
        <div class="card-header">
            
        </div>


        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    

                </div>
            </div>
        </div>
    </div>
</div>


<?php 
include('./employee/assets/inc/footer.php');
?> 


</body>
</html>
