
<!--navbar-->
<section id="topbar">
        <!--topbar-->
        <nav>
            <i class='bx bx-menu toggle-sidebar' ></i>
            <form action="#">
                <div class="form-group">
                    <input type="text" placeholder="Search...">
                    <i class='bx bx-search-alt icon' ></i>
                </div>
            </form>
            <a href="#" class="nav-link">
                <i class='bx bx-bell icon' ></i>
                <span class="badge">5</span>
            </a>
            <a href="#" class="nav-link">
                <i class='bx bx-chat icon' ></i>
                <span class="badge">8</span>
            </a>
            <span class="divider"></span>
            <div class="profile">
                <img src="./assets/image/profile.png" alt="">
                <ul class="profile-link">
                    <li><a href="employee_profile.php"><i class='bx bxs-user-circle icon' ></i>Profile</a></li>
                    <li><a href="employee_settings.php"><i class='bx bx-cog icon' ></i>Settings</a></li>
                    <li><a href="#"><i class='bx bx-log-out icon' ></i>Logout</a></li>
                </ul>
            </div>
        </nav>
        <!--end topbar-->

        <!--end main-->
    <!--</section>-->
    
    <!--end navbar-->
