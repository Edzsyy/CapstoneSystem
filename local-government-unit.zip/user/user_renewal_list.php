<?php 
include('./user/assets/config/dbconn.php');

include('./user/assets/inc/header.php');

include('./user/assets/inc/sidebar.php');

include('./user/assets/inc/navbar.php');

?> 


<!---update user-->
<div class="modal fade" id="updateModal" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="updateModalLabel">Update User</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <div class="mb-3">
                    <label for="updateFirstname" class="form-label">Fisrt Name:</label>
                    <input type="text" class="form-control" id="updateFirstname" placeholder="First Name">
                </div>
                <div class="mb-3">
                    <label for="updateLastname" class="form-label">Last Name:</label>
                    <input type="text" class="form-control" id="updateLastname" placeholder="Last Name">
                </div>
                <div class="mb-3">
                    <label for="updateEmail" class="form-label">Email:</label>
                    <input type="text" class="form-control" id="updateEmail" placeholder="Email">
                </div>
                <div class="mb-3">
                    <label for="updatePhone" class="form-label">Number:</label>
                    <input type="text" class="form-control" id="updatePhone" placeholder="Number">
                </div>
                <div class="mb-3">
                    <label for="updateAddress" class="form-label">Address:</label>
                    <input type="text" class="form-control" id="updateAddress" placeholder="Address">
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="updatedetails()">Update</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <input type="hidden" id="hiddendata">
            </div>
        </div>
    </div>
</div>
<!---end update user-->



<!---QR code-->
<div class="modal fade" id="qrcodeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">QR Code</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <script src="../user/assets/js/html5-qrcode.min.js"></script>

                <style>
                .result {
                    background-color: green;
                    color: #fff;
                    padding: 20px;
                }
                .row {
                    display: flex;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    padding: 10px;
                    border: 1px solid #ddd;
                }
                </style>



                <div class="row">
                    <div class="col">
                        <div style="width: 470px;" id="reader"></div>
                    </div>
                    <div class="col" style="padding: 20px;">
                        <h4>SCAN RESULT</h4>
                        <div id="result">Result Here</div>
                    </div>
                </div>

                <script type="text/javascript">
                function onScanSuccess(qrCodeMessage) 
                {
                    // Extract application ID from QR code message
                    const ApplicationIDMatch = qrCodeMessage.match(/ApplicationID:(\d{11})/);
                    if (applicationIdMatch) 
                    {
                        const application_id = ApplicationIDMatch[1];
                        fetchDataFromServer(application_id);
                    } 
                    else 
                    {
                        document.getElementById('result').innerHTML = '<span class="result">QR code does not contain valid application ID</span>';
                    }
                }

                function onScanError(errorMessage) 
                {
                    // Handle scan error
                    console.error('Scan error:', errorMessage);
                }

                function fetchDataFromServer(application_id) 
                {
                    fetch('fetch_data.php', 
                    {
                        method: 'POST',
                        headers: 
                        {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: new URLSearchParams
                        ({
                            'application_id': application_id
                        })
                    })
                    .then(response => response.json())
                    .then(data => 
                    {
                        renderDataInTable(data);
                    })
                    .catch(error => console.error('Error:', error));
                }

                function renderDataInTable(data) 
                {
                    if (!data || data.length === 0) 
                    {
                        document.getElementById('result').innerHTML = '<span class="result">No data found</span>';
                        return;
                    }

                    let table = '<table>';
                    table += '<tr><th>Application ID</th><th>Owner</th><th>Business Name</th><th>Business Type</th><th>Address</th><th>Status</th></tr>';

                    data.forEach(row => 
                    {
                        table += `<tr>
                            <td>${row.application_id}</td>
                            <td>${row.owner_name}</td>
                            <td>${row.business_name}</td>
                            <td>${row.business_type}</td>
                            <td>${row.address}</td>
                            <td>${row.status}</td>
                        </tr>`;
                    });

                    table += '</table>';

                    document.getElementById('result').innerHTML = table;
                }

                var html5QrcodeScanner = new Html5QrcodeScanner(
                    "reader", { fps: 10, qrbox: 250 });
                html5QrcodeScanner.render(onScanSuccess, onScanError);
                </script>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="qrcode()">Submit</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!---end QR code-->



<div class="data-card">
    <div class="card">
        <div class="card-header">
            <h4>Renewal List
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal" data-bs-target="#qrcodeModal">
                    <i class='bx bx-qr-scan'></i>
                </button>
            </h4>
        </div>


        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <div id="displayDataTable">
                        <!-- user_registration_and_renewal_list_displaydata -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<?php 
include('./user/assets/inc/footer.php');
?> 


<script>
    $(document).ready(function()
    {
        displayData();
    });
    //display function
    function displayData()
    {
        var displayData="true";
        $.ajax
        ({
            url:"./user_renewal_list_displaydata.php",
            type:'post',
            data:{
                displaysend:displayData
            },
            success:function(data,status)
            {
                $('#displayDataTable').html(data);
                $('#updateModal').modal('hide');
            }
        });
    }




    //delete function
    function deleteuser(deleteid)
    {
        $.ajax({
            url:"./user_renewal_list_delete.php",
            type:'post',
            data:{
                deletesend:deleteid
            },
            success:function(data,status){
                //console.log(status);
                displayData();
            }
        });
    }


    //update record
    function getdetails(updateid)
    {
        $('#hiddendata').val(updateid);

        $.post("./user_renewal_list_update.php", {updateid:updateid}, function(data,status)
        {
            var userid =JSON.parse(data);

            $('#fname').val(userid.fname);
            $('#mname').val(userid.mname);
            $('#lname').val(userid.lname);
            $('#address').val(userid.address);
            $('#zip').val(userid.zip);
            $('#business_name').val(userid.business_name);
            $('#phone').val(userid.phone);
            $('#email').val(userid.email);
            $('#com_address').val(userid.com_address);
            $('#building_name').val(userid.building_name);
            $('#building_no').val(userid.building_no);
            $('#street').val(userid.street);
            $('#barangay').val(userid.barangay);
            $('#product').val(userid.product);
            $('#registered_name').val(userid.registered_name);
            $('#rent_per_month').val(userid.rent_per_month);
            $('#period_date').val(userid.period_date);
            $('#date_application').val(userid.date_application);
            $('#reciept').val(userid.reciept);
            $('#or_date').val(userid.or_date);
            $('#amount_paid').val(userid.amount_paid);
            $('#picture').val(userid.picture);

        });

        $('#updateModal').modal("show");
    }

    //update function
    function updatedetails()
    {
        var fname = $('#fname').val();
        var mname = $('#mname').val();
        var lname = $('#lname').val();
        var address = $('#address').val();
        var zip = $('#zip').val();
        var business_name = $('#business_name').val();
        var phone = $('#phone').val();
        var email = $('#email').val();
        var com_address = $('#com_address').val();
        var building_name = $('#building_name').val();
        var building_no = $('#building_no').val();
        var street = $('#street').val();
        var barangay = $('#barangay').val();
        var product = $('#product').val();
        var registered_name = $('#registered_name').val();
        var rent_per_month = $('#rent_per_month').val();
        var period_date = $('#period_date').val();
        var date_application = $('#date_application').val();
        var reciept = $('#reciept').val();
        var or_date = $('#or_date').val();
        var amount_paid = $('#amount_paid').val();
        var picture = $('#picture').val();

        $.post("./user_renewal_list_update.php",
        {
            fname:fname,
            mname:mname,
            lname:lname,
            address:address,
            zip:zip,
            business_name:business_name,
            phone:phone,
            email:email,
            com_address:com_address,
            building_name:building_name,
            building_no:building_no,
            street:street,
            barangay:barangay,
            product:product,
            registered_name:registered_name,
            rent_per_month:rent_per_month,
            period_date:period_date,
            date_application:date_application,
            reciept:reciept,
            or_date:or_date,
            amount_paid:amount_paid,
            picture:picture
        },
        function(data,status)
        {
            $('#updateModal').modal('hide');
            displayData();
        });
    }
    

</script>


</body>
</html>
