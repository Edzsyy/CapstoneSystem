<?php 
include('./user/assets/config/dbconn.php');

include('./user/assets/inc/header.php');

include('./user/assets/inc/sidebar.php');

include('./user/assets/inc/navbar.php');

?> 


<div class="data-card">
    <div class="card">
        <div class="card-header">
            
        </div>


        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    

                </div>
            </div>
        </div>
    </div>
</div>


<?php 
include('./user/assets/inc/footer.php');
?> 


</body>
</html>
