<?php 
ob_start();  // Start output buffering

include('./admin/assets/inc/header.php');
include('./admin/assets/inc/sidebar.php');
include('./admin/assets/inc/navbar.php');
include('./employee/assets/config/dbconn.php');
    $pic_uploaded = 0;

if(isset($_REQUEST['submit']))
{

    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $mname = mysqli_real_escape_string($conn, $_POST['mname']);
    $lname = mysqli_real_escape_string($conn, $_POST['lname']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $zip = mysqli_real_escape_string($conn, $_POST['zip']);
    $business_name = mysqli_real_escape_string($conn, $_POST['business_name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $com_address = mysqli_real_escape_string($conn, $_POST['com_address']);
    $building_name = mysqli_real_escape_string($conn, $_POST['building_name']);
    $building_no = mysqli_real_escape_string($conn, $_POST['building_no']);
    $street = mysqli_real_escape_string($conn, $_POST['street']);
    $barangay = mysqli_real_escape_string($conn, $_POST['barangay']);
    $product = mysqli_real_escape_string($conn, $_POST['product']);
    $registered_name = mysqli_real_escape_string($conn, $_POST['registered_name']);
    $rent_per_month = mysqli_real_escape_string($conn, $_POST['rent_per_month']);
    $period_date = mysqli_real_escape_string($conn, $_POST['period_date']);
    $date_application = mysqli_real_escape_string($conn, $_POST['date_application']);
    $or_date = mysqli_real_escape_string($conn, $_POST['or_date']);
    $amount_paid = mysqli_real_escape_string($conn, $_POST['amount_paid']);

    

    $picture = time().$_FILES["picture"]['name'];
    if(move_uploaded_file($_FILES['picture']['tmp_name'], $_SERVER['DOCUMENT_ROOT'].'../employee/assets/image/'.$picture))
    {
        $target_file = $_SERVER['DOCUMENT_ROOT'].'../employee/assets/image/'.$picture;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $picturename = basename($_FILES['picture']['name']);
        $photo = time().$picturename;

        if($imageFileType != "jpg" && $imageFileType != "jpeg" && $imageFileType != "png")
        {?>
            <script>
                alert("Please upload photo having extension .jpg/.jpeg/.png");
            </script>
        <?php
        }
        else if($_FILES["picture"]["size"] > 2000000)
        {?>
            <script>
                alert("Your photo exceed the size of 2 MB");
            </script>
        <?php
        }
        else
        {
            $pic_uploaded = 1;
        }

    }
    

    if($pic_uploaded == 1)
    { 

    $sql = "INSERT INTO registration (fname, mname, lname, address, zip, business_name, phone, email, com_address, building_name, 
    building_no, street, barangay, product, registered_name, rent_per_month, period_date, date_application, or_date,
    amount_paid, picture) VALUES ('$fname', '$mname', '$lname', '$address', '$zip', '$business_name', '$phone', '$email', '$com_address', '$building_name',
    '$building_no', '$street', '$barangay', '$product', '$registered_name', '$rent_per_month', '$period_date', '$date_application', 
    '$or_date', '$amount_paid', '$picture')";

    $result = mysqli_query($conn, $sql);
    if($result)
        {
            
            header("location: ./admin_registration_list.php");
            exit(0);
        }
    
    }
}

ob_end_flush();  // End output buffering and send all output at once
?> 


<div class="data-card">
    <div class="card">
        <div class="card-header">
            
        </div>


        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <form class="row g-3" id="validated_form" method="post" action="admin_registration.php" enctype="multipart/form-data">
                        <div class="top-form" style="text-align: center;">
                            <h6>Republic of the Philippines</h6>
                            <h6>San Agustin, Metropolitan Manila</h6>
                            <h6>Business Permit & Licence Office</h6>
                            <h5>APPLICATION FORM FOR NEW BUSINESS PERMIT</h5>
                        </div>
                        <div class="col-md-5">
                            <label for="date_application" class="form-label">Date of Application:</label>
                            <input type="date" class="form-control" id="date_application" name="date_application" required>
                        </div>

                        <div class="col-md-2"></div>

                        <div class="col-md-5">
                            <label for="reciept" class="form-label">Official Receipt No.:</label>
                            <input type="text" class="form-control" id="reciept" name="reciept" placeholder="Official Receipt No." required>
                        </div>


                        <div class="col-md-5">
                            <label for="or_date" class="form-label">O.R. Date:</label>
                            <input type="date" class="form-control" id="or_date" name="or_date" required>
                        </div>

                        <div class="col-md-2"></div>

                        <div class="col-md-5">
                            <label for="amount_paid" class="form-label">Amount Paid:</label>
                            <input type="text" class="form-control" id="amount_paid" name="amount_paid" placeholder="Amount Paid" required>
                        </div>

                        <hr>

                        <div class="col-md-4">
                            <label for="fname" class="form-label">First name:</label>
                            <input type="text" class="form-control" id="fname" name="fname" placeholder="First name" required>
                        </div>
                        <div class="col-md-4">
                            <label for="mname" class="form-label">Middle name:</label>
                            <input type="text" class="form-control" id="mname" name="mname" placeholder="Middle name" required>
                        </div>
                        <div class="col-md-4">
                            <label for="lname" class="form-label">Last name:</label>
                            <input type="text" class="form-control" id="lname" name="lname" placeholder="Last name" required>
                        </div>


                        
                        <div class="col-8">
                            <label for="address" class="form-label">Address:</label>
                            <input type="text" class="form-control" id="address" name="address" placeholder="Address" required>
                        </div>
                        <div class="col-4">
                            <label for="zip" class="form-label">Zip:</label>
                            <input type="text" class="form-control" id="zip" name="zip" placeholder="Zip" required>
                        </div>



                        <div class="col-md-4">
                            <label for="business_name" class="form-label">Business Trade Name:</label>
                            <input type="text" class="form-control" id="business_name" name="business_name" placeholder="Business Trade Name" required>
                        </div>
                        <div class="col-md-4">
                            <label for="phone" class="form-label">Contact #:</label>
                            <input type="text" class="form-control" id="phone" name="phone" placeholder="Contact #" required>
                        </div>
                        <div class="col-md-4">
                            <label for="email" class="form-label">Email Address:</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Email Address" required>
                        </div>




                        <div class="col-md-4">
                            <label for="com_address" class="form-label">Commercial Address:</label>
                            <input type="text" class="form-control" id="com_address" name="com_address" placeholder="Commercial Address" required>
                        </div>
                        <div class="col-md-2">
                            <label for="building_name" class="form-label">Building Name:</label>
                            <input type="text" class="form-control" id="building_name" name="building_name" placeholder="Building Name" required>
                        </div>
                        <div class="col-md-2">
                            <label for="building_no" class="form-label"> Building No.:</label>
                            <input type="text" class="form-control" id="building_no" name="building_no" placeholder="Building No." required>
                        </div>
                        <div class="col-md-2">
                            <label for="street" class="form-label">Street:</label>
                            <input type="text" class="form-control" id="street" name="street" placeholder="Street" required>
                        </div>
                        <div class="col-md-2">
                            <label for="barangay" class="form-label">Barangay:</label>
                            <input type="text" class="form-control" id="barangay" name="barangay" placeholder="Barangay" required>
                        </div>



                        <div class="col-md-3">
                            <label for="product" class="form-label">Product/Services:</label>
                            <input type="text" class="form-control" id="product" name="product" placeholder="Product/Services" required>
                        </div>
                        <div class="col-md-3">
                            <label for="registered_name" class="form-label">Registered Name:</label>
                            <input type="text" class="form-control" id="registered_name" name="registered_name" placeholder="Registered Name" required>
                        </div>
                        <div class="col-md-3">
                            <label for="rent_per_month" class="form-label">Rent Per Month:</label>
                            <input type="text" class="form-control" id="rent_per_month" name="rent_per_month" placeholder="Rent per Month" required>
                        </div>
                        <div class="col-md-3">
                            <label for="period_date" class="form-label">Period of Date:</label>
                            <input type="date" class="form-control" id="period_date" name="period_date" required>
                        </div>
                        <div class="col-md-3">
                            <label for="picture" class="form-label">Upload File:</label>
                            <input type="file" class="form-control" id="picture" name="picture" required>
                        </div>

                        <div class="col-12">
                            <button type="submit" class="btn btn-primary" id="submit" name="submit" value="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php 
include('./admin/assets/inc/footer.php');
?> 


</body>
</html>
