<?php 
include('./admin/assets/config/dbconn.php');

include('./admin/assets/inc/header.php');

include('./admin/assets/inc/sidebar.php');

include('./admin/assets/inc/navbar.php');

?> 


<div class="data-card">
    <div class="card">
        <div class="card-header">
            
        </div>


        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    

                </div>
            </div>
        </div>
    </div>
</div>


<?php 
include('./admin/assets/inc/footer.php');
?> 


</body>
</html>
